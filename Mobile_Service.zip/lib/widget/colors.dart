import 'package:flutter/material.dart';

class CustomColor {
  static const Color primaryColor = Color(0xfff241F1F);
  static const Color secondaryColor = Color(0xffffffff);
  // static const Color secondaryColor = Color(0xfff241F1F);
  // static const Color primaryColor = Color(0xffffffff);
}
